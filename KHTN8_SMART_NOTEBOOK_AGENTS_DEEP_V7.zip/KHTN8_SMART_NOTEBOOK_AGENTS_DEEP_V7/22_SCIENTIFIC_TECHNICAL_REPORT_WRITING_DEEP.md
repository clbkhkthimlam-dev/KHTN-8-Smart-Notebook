# 22_SCIENTIFIC_TECHNICAL_REPORT_WRITING_DEEP

## 0. Mục đích

Tài liệu này là chuẩn điều phối cho việc xây dựng **Bản thuyết minh/ Báo cáo đề tài khoa học kỹ thuật** của dự án:

**SỔ TAY KHOA HỌC TỰ NHIÊN THÔNG MINH ỨNG DỤNG AI HỖ TRỢ CÁ NHÂN HÓA HỌC TẬP CHO HỌC SINH THCS**

Mục tiêu của agent không phải viết một bài quảng bá sản phẩm, mà phải tạo được một chuỗi lập luận có thể kiểm chứng:

**Ý tưởng từ thực tế → Vấn đề → Câu hỏi nghiên cứu → Nghiên cứu tài liệu → Tổng hợp bằng chứng → Khoảng trống khoa học/thực tiễn → Tính mới → Tính sáng tạo → Ý tưởng giải pháp → Mục tiêu → Thiết kế nghiên cứu/kỹ thuật → Xây dựng sản phẩm → Thử nghiệm → Phân tích dữ liệu → Kết luận → Hạn chế → Cải tiến tiếp theo.**

---

## 1. Hai nguồn mẫu bắt buộc phải được xem là khung tham chiếu

### 1.1. Mẫu “BÁO CÁO KẾT QUẢ THỰC HIỆN DỰ ÁN”

Nguồn mẫu quy định dự án khoa học có ba khối chính:

1. Câu hỏi nghiên cứu.
2. Thiết kế và phương pháp.
3. Thực hiện: thu thập, phân tích và giải thích dữ liệu.

Với dự án kỹ thuật, mẫu quy định:

1. Vấn đề nghiên cứu: mô tả đòi hỏi thực tế, xác định vấn đề và tiêu chí giải pháp.
2. Thiết kế và phương pháp: khảo sát các giải pháp, phân tích, lựa chọn và thiết kế mô hình/nguyên mẫu.
3. Thực hiện: chế tạo và kiểm tra trong nhiều điều kiện, chứng minh tính khả thi/hiệu quả và hoàn thiện sản phẩm.

Tham chiếu trực tiếp từ tài liệu mẫu: trang 1, các mục I và II. Mẫu cũng ghi giới hạn 15 trang và quy định trình bày A4, Times New Roman, cỡ 14, cách dòng đơn; dự án này có thể dùng cỡ 13 theo yêu cầu người dùng nhưng phải có một biến cấu hình `competition_font_size` cho phép chuyển sang 14 khi điều lệ bắt buộc.

### 1.2. Mẫu “Bài thuyết minh – Đề tài lúa”

Bài mẫu triển khai theo mạch rất hữu ích cho dự án KHTN Smart Notebook:

- A. Thông tin chung.
- B. Phần mô tả nội dung sản phẩm.
- 1. Tính mới, tính sáng tạo.
  - 1.1. Vấn đề quan tâm.
  - 1.2. Nghiên cứu tổng quan.
  - các phương pháp hiện có.
  - bảng so sánh các nghiên cứu/sản phẩm.
  - khoảng trống nghiên cứu.
  - 1.3. Tính mới.
  - 1.4. Tính sáng tạo.
- 2. Ý tưởng xây dựng mô hình, sản phẩm.
- 3. Nguyên, vật liệu chế tạo sản phẩm.
  - nguyên lý hoạt động.
  - phần cứng/phần mềm.
  - chế tạo.
- 4. Cách sử dụng, vận hành.
- 5. Đánh giá giải pháp.
- 6. Phụ lục minh họa.
- Kế hoạch kinh doanh/phát triển và tài liệu nghiên cứu.

Bài mẫu đặc biệt quan trọng ở mạch **vấn đề → tổng quan → bảng so sánh → khoảng trống → tính mới → tính sáng tạo → ý tưởng → chế tạo → vận hành → đánh giá**, không được đảo ngược thứ tự thành “có sản phẩm trước rồi mới tìm lý do”.

Nguồn mẫu cũng cho thấy họ đã đưa nghiên cứu trước đây vào một bảng so sánh theo mô hình AI, nền tảng, hiệu năng, yêu cầu phần cứng/Internet, mức phù hợp Việt Nam và triển khai; sau đó mới nêu khoảng trống là phần lớn hệ thống tập trung vào nhận diện bệnh nhưng ít tích hợp thông số môi trường/đất. Đây là mô hình trình bày cần chuyển sang bài KHTN Smart Notebook.

---

## 2. Nguyên tắc khoa học cốt lõi

### 2.1. Không được “bịa khoảng trống”

Không được viết:

> “Chưa có nghiên cứu nào…”

chỉ vì không tìm thấy nhanh trên Google.

Phải dùng phát biểu có mức độ bằng chứng:

- `well established`: đã có nhiều bằng chứng.
- `partially addressed`: đã có nghiên cứu nhưng chỉ giải quyết một phần.
- `under-explored`: có nghiên cứu nhưng còn hạn chế về bối cảnh/đối tượng/phương pháp.
- `unmet need`: tồn tại nhu cầu thực tế chưa được đáp ứng tốt.
- `gap candidate`: khoảng trống giả định, cần tiếp tục xác minh.

### 2.2. Không được lấy “tính năng” làm “tính mới”

Ví dụ:

- “Có chatbot” không tự động là tính mới.
- “Có AI” không tự động là tính mới.
- “Có video” không tự động là tính mới.
- “Có Knowledge Graph” không tự động là tính mới.

Tính mới chỉ được nêu khi có lập luận đối chiếu:

**Điểm đã có trong tài liệu trước đây + hạn chế cụ thể + giải pháp của đề tài + cơ chế khác biệt + bằng chứng cho thấy giải pháp hoạt động.**

### 2.3. Tách ba khái niệm

- **Tính mới:** đề tài bổ sung/khác biệt điều gì so với giải pháp/nghiên cứu trước.
- **Tính sáng tạo:** cách kết hợp, thiết kế hoặc cơ chế giải quyết khác biệt ra sao.
- **Tính hiệu quả:** dữ liệu cho thấy giải pháp có cải thiện kết quả hay không.

Không dùng một bằng chứng để chứng minh cả ba nếu nó không đủ.

---

## 3. Quy trình nghiên cứu từ ý tưởng đến khoảng trống khoa học

### Bước 1 — Quan sát thực tế

Đầu ra bắt buộc:

- hiện tượng/vấn đề quan sát được;
- đối tượng bị ảnh hưởng;
- bối cảnh;
- hậu quả;
- bằng chứng ban đầu;
- nhu cầu của người dùng.

Đối với Smart Notebook:

- học sinh KHTN 8 học kiến thức theo bài rời rạc;
- cùng một khái niệm có thể xuất hiện trong nhiều bối cảnh;
- học sinh có thể nhớ định nghĩa nhưng gặp khó khi giải thích hiện tượng/chuyển giao;
- nguồn tài liệu ngoài SGK phong phú nhưng phân tán;
- câu trả lời AI có nguy cơ đúng về văn bản nhưng sai kiến thức, sai công thức, thiếu dẫn nguồn;
- dữ liệu học tập có thể bị bỏ phí nếu không được gom lại theo kiến thức/kỹ năng/sai lầm.

Lưu ý: các nhận định trên chỉ là **giả thuyết vấn đề** cho đề tài. Phải khảo sát học sinh/giáo viên để biến thành bằng chứng thực nghiệm.

### Bước 2 — Đóng khung vấn đề

Không viết “học sinh học KHTN chưa tốt”.

Phải chuyển thành một vấn đề có thể đo:

> “Học sinh lớp 8 gặp khó khăn khi chuyển từ kiến thức khái niệm trong SGK sang việc giải thích hiện tượng thực tế và giải quyết tình huống liên môn; tài nguyên hỗ trợ bị phân tán; giáo viên khó theo dõi lỗi nguyên nhân gốc và cá nhân hóa nhiệm vụ.”

### Bước 3 — Đặt câu hỏi nghiên cứu sơ bộ

Tối đa 2–3 câu hỏi chính cho báo cáo 12–15 trang.

Ví dụ:

**RQ1.** Hệ thống Sổ tay KHTN thông minh dựa trên hiện tượng, Knowledge Graph và AI cá nhân hóa có giúp tăng mức độ nắm vững kiến thức và khả năng vận dụng của học sinh lớp 8 không?

**RQ2.** Hệ thống có làm giảm tỷ lệ lặp lại cùng một nhóm sai lầm nhận thức hay không?

**RQ3.** Việc nối kiến thức giữa các phân môn bằng Problem-Solving Graph có cải thiện khả năng giải quyết tình huống liên môn hay không?

### Bước 4 — Xây dựng chiến lược tìm tài liệu

Phải tìm theo 4 lớp:

1. **Curriculum layer:** SGK/SGV KHTN 8 và yêu cầu cần đạt.
2. **Pedagogy layer:** inquiry-based learning, phenomenon-based learning, formative assessment, personalized learning.
3. **Technology layer:** AI tutor, adaptive learning, learning analytics, knowledge graph, educational recommender.
4. **Evidence layer:** nghiên cứu thực nghiệm về tác động tới learning gain, transfer, misconceptions, engagement, usability.

### Bước 5 — Thiết kế truy vấn tìm kiếm

Mỗi truy vấn phải có cấu trúc:

`[đối tượng] + [can thiệp] + [kết quả] + [bối cảnh]`

Ví dụ:

- `middle school science AI tutor learning outcomes`
- `K-12 science personalized learning misconceptions`
- `phenomenon based science learning middle school transfer`
- `knowledge graph personalized learning science education`
- `AI formative assessment misconception diagnosis science`
- `interdisciplinary problem solving middle school science`
- `educational technology learning gain pretest posttest middle school`

Không chỉ tìm theo từ “Smart Notebook”.

### Bước 6 — Chọn nguồn

Ưu tiên:

1. bài báo peer-reviewed;
2. systematic review/meta-analysis;
3. sách/chương sách học thuật;
4. báo cáo chính thức của trường/đơn vị nghiên cứu;
5. tài liệu giáo dục uy tín;
6. website sản phẩm — chỉ dùng để mô tả tính năng sản phẩm, không dùng làm bằng chứng hiệu quả nếu không có dữ liệu độc lập.

### Bước 7 — Lập ma trận bằng chứng

Mỗi nghiên cứu phải được ghi:

| Trường | Nội dung |
|---|---|
| Citation ID | mã tài liệu |
| Research question | nghiên cứu gì |
| Population | ai |
| Context | bối cảnh |
| Intervention | giải pháp |
| Method | phương pháp |
| Outcomes | chỉ số |
| Results | kết quả |
| Limitation | hạn chế |
| Relevance | liên quan đến Smart Notebook thế nào |
| Gap contribution | giúp xác định khoảng trống nào |

### Bước 8 — Tổng hợp chứ không kể lể

Không viết 10 đoạn “nghiên cứu A làm…, nghiên cứu B làm…”.

Phải nhóm nghiên cứu theo vấn đề:

- nhóm 1: hỗ trợ giải thích kiến thức;
- nhóm 2: cá nhân hóa;
- nhóm 3: AI tutor;
- nhóm 4: misconception diagnosis;
- nhóm 5: phenomenon/context learning;
- nhóm 6: interdisciplinary problem solving;
- nhóm 7: learning analytics.

### Bước 9 — Lập bảng đối chiếu khoảng trống

Ví dụ mẫu:

| Chiều nghiên cứu | Đã có | Hạn chế | Đề tài đề xuất |
|---|---|---|---|
| Nội dung | kho bài học số | thường theo bài/khóa | Knowledge Graph theo kiến thức nguyên tử |
| Ngữ cảnh | ví dụ/hoạt động | ít nối thành chuỗi giải quyết vấn đề | Phenomenon + Problem Graph |
| AI | giải thích/hỏi đáp | dễ trả lời trực tiếp | Socratic + hint + diagnosis |
| Cá nhân hóa | điểm số | chưa luôn truy nguyên nguyên nhân | root-cause + prerequisite |
| Liên môn | tài liệu tích hợp | thiếu cơ chế gọi đúng kiến thức | Minimal Sufficient Knowledge Path |
| Dữ liệu | log hoạt động | khó gắn với tiến bộ kiến thức | learner model + event graph |
| Nguồn | web đa dạng | phân tán/khó đánh giá | evidence/resource lattice |
| Công thức | hiển thị toán | có nguy cơ lỗi render | formula provenance + semantic/visual QA |

Đây là **khung giả thuyết**; chỉ được chuyển sang kết luận khi có tài liệu thực tế chứng minh.

### Bước 10 — Suy ra khoảng trống

Công thức lập luận:

`Known → Partial → Limitation → Unmet need → Testable gap`

Mẫu viết:

> “Các nghiên cứu hiện có đã chứng minh … Tuy nhiên, phần lớn tập trung vào …, trong khi … chưa được giải quyết đầy đủ, đặc biệt trong bối cảnh … Vì vậy, khoảng trống mà đề tài tập trung kiểm chứng là liệu có thể xây dựng một hệ thống … để … và đo lường tác động bằng … hay không.”

### Bước 11 — Từ gap suy ra tính mới

Mỗi tính mới phải có 3 ô:

`Gap ID → Novelty statement → Verification evidence`

Ví dụ:

`GAP-03 → liên kết hiện tượng + kiến thức + tình huống liên môn thành chuỗi giải quyết vấn đề → kiểm chứng bằng test transfer liên môn.`

---

## 4. Khung nghiên cứu cho KHTN Smart Notebook

### 4.1. Ý tưởng tổng thể

Không mô tả là “web học KHTN có AI”.

Cách mô tả nghiên cứu:

> “Xây dựng và đánh giá một hệ thống sổ tay KHTN thông minh dựa trên Knowledge Graph và Problem-Solving Graph, trong đó mỗi đơn vị kiến thức được truy nguyên về SGK/SGV, gắn với hiện tượng thực tế, dữ liệu, tài nguyên web và hoạt động tương tác; AI sử dụng hồ sơ người học để điều hướng nhiệm vụ, chẩn đoán sai lầm và lựa chọn kiến thức cần thiết nhằm hỗ trợ giải quyết vấn đề.”

### 4.2. Mô hình logic

`Input`
- SGK/SGV KHTN 8;
- knowledge atoms;
- nguồn web;
- dữ liệu học sinh;
- nhiệm vụ/bài tập;
- interaction logs.

`Process`
- retrieval;
- graph mapping;
- scenario generation;
- diagnosis;
- adaptive routing;
- experimentation;
- feedback.

`Output`
- learning gain;
- transfer;
- reduction of repeated errors;
- personalized path;
- evidence-based explanation;
- usable product.

### 4.3. Biến nghiên cứu

**Independent/intervention variable:** sử dụng Smart Notebook theo quy trình thiết kế.

**Primary outcomes:**
- normalized learning gain;
- transfer score;
- repeated misconception rate.

**Secondary outcomes:**
- task completion time;
- hint dependence;
- engagement;
- usability;
- retention nếu đủ thời gian theo dõi.

**Covariates nếu có:**
- pretest score;
- prior achievement;
- lesson exposure;
- baseline digital familiarity.

### 4.4. Mô hình nghiên cứu khuyến nghị

Kết hợp:

**Design-Based Research (DBR)** cho quá trình xây dựng/cải tiến sản phẩm + **quasi-experimental / pretest-posttest** cho đánh giá hiệu quả.

DBR phù hợp vì cho phép vòng lặp phân tích → thiết kế → triển khai → đánh giá → sửa đổi trong bối cảnh học tập thật. Nhiều công trình giáo dục công nghệ mô tả DBR theo các pha phân tích/khảo sát, thiết kế/xây dựng và đánh giá/phản tư; một số nghiên cứu nhấn mạnh việc lặp lại các vòng thiết kế dựa trên dữ liệu thực tế. citeturn817541search1turn817541search2turn817541search7

---

## 5. Thiết kế thử nghiệm cụ thể cho đề tài

### Phương án A — Tối giản, phù hợp học sinh

`Pretest → can thiệp 6–8 tuần → Posttest`

Một lớp hoặc hai nhóm nếu điều kiện cho phép.

### Phương án B — Mạnh hơn

`Experimental group` sử dụng Smart Notebook.

`Comparison group` học theo tài liệu/phương pháp thông thường.

Cả hai nhóm làm cùng pretest và posttest.

### Phương án C — Mạnh nhất trong điều kiện trường học

- matching nhóm theo pretest;
- cùng thời lượng;
- cùng chủ đề;
- giáo viên/điều kiện lớp tương đương;
- chỉ khác can thiệp số;
- ghi lại fidelity of implementation;
- đánh giá posttest + delayed posttest nếu có thể.

Không được gọi là “randomized controlled trial” nếu không thực sự ngẫu nhiên hóa.

---

## 6. Bộ công cụ đo lường

### 6.1. Kiến thức

- câu hỏi khái niệm;
- nhận diện;
- giải thích;
- tính toán;
- đọc biểu đồ;
- vận dụng.

### 6.2. Chuyển giao

Cho học sinh tình huống chưa xuất hiện trong tài liệu học.

Đo:

- chọn kiến thức đúng;
- lập luận;
- bằng chứng;
- giải pháp;
- tính đúng;
- giải thích nguyên nhân.

### 6.3. Misconception

Gán từng lỗi vào ontology:

`CONCEPT`, `FORMULA`, `UNIT`, `GRAPH`, `CAUSAL_REASONING`, `READING_DATA`, `TRANSFER`, `PROCEDURE`.

So sánh tỷ lệ lặp lại cùng `error_class` giữa pre/post hoặc qua các vòng học.

### 6.4. Usability

- completion rate;
- task success;
- time-on-task;
- System Usability Scale hoặc thang Likert phù hợp.

### 6.5. Learning analytics

Từ Sheet/App Script/event logs:

- attempts;
- hints;
- corrections;
- resource opens;
- scenario transitions;
- formula views;
- export usage;
- intervention path;
- mastery updates.

---

## 7. Phân tích thống kê

Không chỉ báo cáo “điểm trung bình tăng”.

Báo cáo tối thiểu:

- `n`;
- mean ± SD hoặc median/IQR tùy dữ liệu;
- baseline comparability nếu có nhóm so sánh;
- pre/post change;
- effect size;
- confidence interval nếu có thể;
- p-value khi kiểm định thích hợp;
- dữ liệu thiếu;
- outlier và cách xử lý;
- biểu đồ phù hợp.

Khi có thể, ưu tiên diễn giải **effect size và khoảng tin cậy**, không chỉ dựa vào p-value. Đây cũng là thực hành được khuyến nghị trong hướng dẫn IMRAD hiện đại. citeturn615619search2turn615619search36

Không được dùng “post hoc power” như cách chữa cho thiết kế cỡ mẫu kém; nếu cỡ mẫu thuận tiện, phải nêu rõ đây là giới hạn. citeturn615619search2

---

## 8. Cấu trúc bài báo cáo 12–15 trang A4

### 8.1. Mục tiêu dàn trang

Ưu tiên **13–15 trang cả bìa/phụ lục/tài liệu tham khảo**, tùy yêu cầu cuộc thi. Không kéo dài bằng khoảng trắng, không dùng xuống dòng nhân tạo.

### 8.2. Dàn trang khuyến nghị

**Trang 1:** Bìa.

**Trang 2:** A. Thông tin chung + 1.1 Vấn đề thực tế.

**Trang 3–4:** 1.2 Nghiên cứu tổng quan.

**Trang 5:** Ma trận nghiên cứu + khoảng trống.

**Trang 6:** Tính mới + tính sáng tạo + ý tưởng tổng thể + câu hỏi nghiên cứu + mục tiêu.

**Trang 7–8:** Thiết kế hệ thống + kiến trúc + phương pháp + dữ liệu + quy trình.

**Trang 9–10:** Xây dựng sản phẩm + các module chính + tình huống thực tế + liên môn.

**Trang 11:** Thử nghiệm/đánh giá.

**Trang 12:** Kết quả dữ liệu + bảng/biểu đồ.

**Trang 13:** Thảo luận + so sánh với nghiên cứu trước.

**Trang 14:** Hạn chế + cải tiến + khả năng áp dụng/triển khai.

**Trang 15:** Kết luận + tài liệu tham khảo hoặc phụ lục rút gọn.

Nếu phụ lục/tài liệu tham khảo chiếm nhiều diện tích, rút phần mô tả sản phẩm, không được giảm phần phương pháp và bằng chứng.

---

## 9. Cấu trúc nội dung chính để giống phong cách “bài thuyết minh đề tài lúa” nhưng chặt chẽ khoa học hơn

# A. THÔNG TIN CHUNG

1. Tên đề tài.
2. Lĩnh vực.
3. Tác giả/nhóm.
4. Đơn vị.
5. Thời gian.

# B. PHẦN MÔ TẢ NỘI DUNG ĐỀ TÀI

## 1. TÍNH MỚI, TÍNH SÁNG TẠO

### 1.1. Vấn đề thực tế

- bối cảnh KHTN 8;
- khó khăn của học sinh;
- bằng chứng khảo sát ban đầu;
- hậu quả;
- nhu cầu.

### 1.2. Nghiên cứu tổng quan

#### 1.2.1. Cách học KHTN hiện có
#### 1.2.2. Tài nguyên số/simulation/video
#### 1.2.3. AI tutor/adaptive learning
#### 1.2.4. Knowledge Graph/learning analytics
#### 1.2.5. Phenomenon-based/contextual learning
#### 1.2.6. Nghiên cứu về misconception và transfer
#### 1.2.7. Bảng so sánh các nghiên cứu

### 1.2.8. Khoảng trống khoa học/thực tiễn

Phải dùng ma trận bằng chứng.

### 1.3. Tính mới

Chỉ công bố các novel claims có `evidence_id`.

### 1.4. Tính sáng tạo

Giải thích cơ chế kết hợp.

## 2. Ý TƯỞNG XÂY DỰNG MÔ HÌNH, SẢN PHẨM

- ý tưởng xuất phát từ gap;
- logic giải pháp;
- sơ đồ tổng thể;
- user journey;
- problem-solving journey.

## 3. NGUYÊN VẬT LIỆU VÀ PHƯƠNG PHÁP

### 3.1. Kiến trúc
### 3.2. Knowledge Base
### 3.3. AI pipeline
### 3.4. Web data/resource pipeline
### 3.5. Google Sheets/App Script/data pipeline
### 3.6. Formula integrity
### 3.7. Document export
### 3.8. An toàn dữ liệu

## 4. CHẾ TẠO / PHÁT TRIỂN

Trình bày các phiên bản:

`v0 → prototype → pilot → V1 → cải tiến → V2`

Mỗi lần thay đổi phải có:

`Problem evidence → change → rationale → validation evidence`.

## 5. CÁCH SỬ DỤNG / VẬN HÀNH

Mô tả bằng ảnh và flow.

## 6. ĐÁNH GIÁ GIẢI PHÁP

### 6.1. Thiết kế thử nghiệm
### 6.2. Bộ dữ liệu
### 6.3. Kết quả
### 6.4. Phân tích thống kê
### 6.5. So sánh với cách học thông thường/nghiên cứu trước
### 6.6. Hạn chế
### 6.7. Hiệu quả và khả năng áp dụng

## 7. ĐỊNH HƯỚNG CẢI TIẾN

- mở rộng lớp;
- mở rộng chương/bài;
- cải tiến AI;
- tăng dữ liệu thực tế;
- nâng chất lượng adaptive path;
- nâng Formula QA;
- nâng nguồn Web;
- đánh giá dài hạn.

## 8. KẾT LUẬN

Chỉ kết luận đúng phạm vi dữ liệu.

## 9. TÀI LIỆU THAM KHẢO

Theo một chuẩn thống nhất.

---

## 10. Quan hệ bắt buộc giữa các phần

Agent phải tạo traceability matrix:

| Claim | Source/Evidence | Method | Result | Conclusion |
|---|---|---|---|---|
| Vấn đề tồn tại | survey | survey | % học sinh | problem justified |
| Gap | literature | review matrix | pattern | gap candidate |
| Novelty | gap + design | prototype | feature | novelty supported |
| Hiệu quả | test | pre/post | gain | effectiveness |
| Liên môn | transfer task | rubric | score | interdisciplinary claim |

Nếu một phát biểu quan trọng không nối được với nguồn hoặc dữ liệu, đánh dấu `UNSUPPORTED_CLAIM`.

---

## 11. Phương pháp cải tiến sản phẩm

Dùng vòng lặp:

`OBSERVE → MEASURE → DIAGNOSE → REDESIGN → TEST → COMPARE → KEEP/ROLLBACK`.

### Ví dụ

**Phát hiện:** học sinh xem nhiều nhưng transfer thấp.

**Chẩn đoán:** nội dung cung cấp quá nhiều thông tin, thiếu nhiệm vụ chuyển giao.

**Cải tiến:** thêm scenario-based transfer và Socratic hints.

**Kiểm tra:** so sánh transfer score trước/sau.

Không viết “cải tiến giao diện vì thấy đẹp hơn”; phải gắn quyết định giao diện với một chỉ số.

---

## 12. Tính tái lập

Phương pháp phải đủ chi tiết để người khác tái hiện:

- số người tham gia;
- tiêu chí chọn;
- thời gian;
- thiết bị;
- phần mềm;
- phiên bản hệ thống;
- prompt/AI policy nếu có ảnh hưởng;
- cấu hình dữ liệu;
- thuật toán;
- cách chấm;
- công thức thống kê;
- cách xử lý thiếu dữ liệu.

Đây là mục tiêu cốt lõi của phần Methods trong báo cáo khoa học. citeturn615619search6

---

## 13. Quy tắc viết chống “văn AI kéo giãn”

### 13.1. Không xuống dòng sau mọi câu

Chỉ xuống dòng khi:

- bắt đầu mục mới;
- bảng;
- hình;
- công thức;
- danh sách có cấu trúc.

### 13.2. Mỗi đoạn 4–8 câu

Một đoạn = một luận điểm.

### 13.3. Không dùng bullet thay cho văn bản khoa học

Chỉ dùng bullet cho quy trình, tiêu chí, cấu hình, checklist.

### 13.4. Không lặp cùng một ý

Mỗi bằng chứng nên xuất hiện một lần ở phần chính; phần thảo luận chỉ diễn giải ý nghĩa.

### 13.5. Không mô tả sản phẩm trước khi chứng minh nhu cầu

Thứ tự bắt buộc:

`Need → Evidence → Gap → Design → Build → Test`.

### 13.6. Từ ngữ phải có mức độ chắc chắn

Không dùng “chắc chắn”, “tốt nhất”, “đầu tiên”, “duy nhất” nếu không có bằng chứng.

---

## 14. Quy tắc sử dụng hình ảnh trong bài

Mỗi hình phải có chức năng khoa học:

- hình hiện trạng;
- hình nghiên cứu/nguồn;
- sơ đồ gap;
- sơ đồ giải pháp;
- kiến trúc hệ thống;
- giao diện;
- quy trình thí nghiệm;
- biểu đồ kết quả;
- ảnh minh chứng thực địa.

Không dùng ảnh trang trí.

Caption phải trả lời “hình này chứng minh/giải thích điều gì?”.

---

## 15. Phương pháp viết phần nghiên cứu tổng quan cho Smart Notebook

### 15.1. Không tìm “web học KHTN 8” đơn thuần

Phải nghiên cứu theo cơ chế vấn đề.

Ví dụ nhóm truy vấn:

**Learning science**
- phenomenon-based learning;
- inquiry-based science;
- science misconceptions;
- transfer of learning;
- interdisciplinary science learning.

**AI education**
- AI tutor;
- adaptive feedback;
- automated diagnosis;
- learning analytics;
- personalized learning.

**Knowledge representation**
- knowledge graph education;
- prerequisite graph;
- concept mapping;
- curriculum knowledge graph.

**Resources**
- simulation-based science learning;
- multimedia learning;
- open educational resources.

### 15.2. Mỗi nhóm phải trả lời

1. Họ đã giải quyết gì?
2. Với ai?
3. Trong bối cảnh nào?
4. Bằng phương pháp nào?
5. Đo bằng chỉ số gì?
6. Hạn chế ở đâu?
7. Phần nào liên quan trực tiếp đến Smart Notebook?

---

## 16. Phương pháp suy ra tính mới của Smart Notebook

Không bắt đầu từ danh sách tính năng.

Bắt đầu từ các gap đã xác minh.

Ví dụ cấu trúc lập luận mục tiêu:

### GAP-A — kiến thức phân mảnh
→ **NOVELTY-A:** Knowledge Graph cấp knowledge atom + prerequisite + transfer.

### GAP-B — AI thường trả lời trực tiếp
→ **NOVELTY-B:** Socratic adaptive tutor + root-cause diagnosis.

### GAP-C — hiện tượng và kiến thức bị tách rời
→ **NOVELTY-C:** Phenomenon Graph + Problem-Solving Graph.

### GAP-D — học sinh cần nhiều kiểu bằng chứng
→ **NOVELTY-D:** resource/evidence lattice liên kết SGK/SGV, simulation, video, hình ảnh, dữ liệu web.

### GAP-E — học tập có dữ liệu nhưng ít phản hồi nguyên nhân
→ **NOVELTY-E:** learner/event graph → misconception → prerequisite → next task.

Những nhãn GAP/NOVELTY ở trên là **khung thiết kế để kiểm chứng**, không phải kết luận khoa học có sẵn.

---

## 17. Bộ câu hỏi phản biện trước khi nộp

### Vấn đề
- Có dữ liệu khảo sát không?
- Có bằng chứng ngoài ý kiến chủ quan không?

### Tổng quan
- Có đủ nghiên cứu liên quan không?
- Bảng so sánh có cùng tiêu chí không?
- Có phân biệt nghiên cứu, sản phẩm thương mại, website và tài liệu phổ biến không?

### Gap
- Có thực sự suy ra từ tổng quan không?
- Có câu nào vượt quá bằng chứng không?

### Tính mới
- Mỗi claim có prior-art comparison không?
- Có thể chỉ ra chính xác điểm khác biệt không?

### Phương pháp
- Có thể tái lập không?
- Có biến độc lập/phụ thuộc rõ không?
- Có kế hoạch phân tích dữ liệu từ trước không?

### Kết quả
- Có số liệu thô/đã xử lý?
- Có biểu đồ/bảng phù hợp?
- Kết quả có đúng thứ tự với phương pháp?

### Thảo luận
- Có so với nghiên cứu trước không?
- Có nêu kết quả không phù hợp kỳ vọng không?
- Có thừa nhận hạn chế không?

### Sản phẩm
- Mỗi tính năng quan trọng có bằng chứng hiệu quả?
- Có chứng minh được web thực sự hoạt động?

---

## 18. Cổng kiểm duyệt cuối

Chỉ cho phép `REPORT_READY = PASS` khi:

`SOURCE_GROUNDED = PASS`

`LITERATURE_MATRIX = COMPLETE`

`GAP_CHAIN = VALID`

`NOVELTY_TRACE = COMPLETE`

`OBJECTIVES_MEASURABLE = PASS`

`METHOD_REPRODUCIBLE = PASS`

`DATA_ANALYSIS_ALIGNED = PASS`

`RESULTS_METHOD_MATCH = PASS`

`FORMULA_INTEGRITY = PASS`

`VIETNAMESE_UNICODE = PASS`

`FIGURE_TABLE_CITATIONS = PASS`

`PAGE_LIMIT = PASS`

`STYLE_TNR = PASS`

`NO_UNSUPPORTED_CLAIMS = PASS`

`FINAL_CONCLUSION_WITHIN_EVIDENCE = PASS`

Chỉ cần một mục `FAIL` thì không xuất bản bản cuối.

---

## 19. Nguyên tắc cuối cùng

Bài báo cáo phải đọc như một **nghiên cứu đã có bằng chứng**, không phải như một brochure giới thiệu sản phẩm.

Mạch thuyết phục nhất:

**Một vấn đề thật → nhiều bằng chứng → tổng quan nghiên cứu → hạn chế hiện tại → khoảng trống có thể kiểm chứng → tính mới có nguồn gốc từ gap → thiết kế giải pháp → sản phẩm → thử nghiệm → dữ liệu → phân tích → kết luận → cải tiến tiếp theo.**

Cấu trúc IMRaD được dùng rộng rãi trong báo cáo nghiên cứu khoa học và nhấn mạnh Introduction/Methods/Results/Discussion; phần Introduction thường dẫn từ vấn đề và nghiên cứu trước đến gap, câu hỏi và mục tiêu; Methods phải đủ để tái lập; Results trình bày phát hiện theo đúng phương pháp; Discussion giải thích ý nghĩa và đối chiếu với tri thức trước đó. citeturn615619search1turn615619search6turn615619search0

Đối với Smart Notebook, hãy **giữ khung bố trí gần mẫu thuyết minh cuộc thi**, nhưng nâng chất lượng lập luận lên chuẩn nghiên cứu: không chỉ kể “đã làm gì”, mà phải trả lời rõ **vì sao làm, dựa trên bằng chứng nào, khoảng trống nào, kiểm tra bằng cách nào và dữ liệu chứng minh được điều gì**.
